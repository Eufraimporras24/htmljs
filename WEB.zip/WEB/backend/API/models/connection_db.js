const mysql = require('mysql')


const database =mysql.createConnection({
    host: "localhost",
    user: "root",
    database: "pador_appointment_system",

})

const connectDatabase = ()=>{
    database.connect((error)=>{
        if (error){n
            console.log("Error connecting to Database")
        }
        else {
            console.log("Successfully connected to the database.")
        }
    })
}

module.exports = {
    database,
    connectDatabase
}
